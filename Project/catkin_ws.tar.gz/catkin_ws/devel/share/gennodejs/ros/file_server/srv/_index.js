
"use strict";

let SaveBinaryFile = require('./SaveBinaryFile.js')
let GetBinaryFile = require('./GetBinaryFile.js')

module.exports = {
  SaveBinaryFile: SaveBinaryFile,
  GetBinaryFile: GetBinaryFile,
};
