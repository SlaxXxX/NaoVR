^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package nao_extras
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2015-08-11)
------------------

0.3.0 (2015-07-31)
------------------

0.2.2 (2014-11-13)
------------------
* comply to the new naoqi organization
* Contributors: Vincent Rabaud

0.2.1 (2014-09-07)
------------------
* Fix package.xml files
* Catkinization of nao_extras, based on commit cb7aedce3c7a3ea3391319f0b7e9aeb78ed13233
* Contributors: Armin Hornung

0.2.0 (2013-10-26)
------------------

0.1.0 (2013-07-30)
------------------
