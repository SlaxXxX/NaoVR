nao_extras
==========

ROS stack for the Nao robot, see http://www.ros.org/wiki/nao_extras

Continues from the renamed nao_common stack: https://github.com/ahornung/nao_common
