THIS PACKAGE IS BASED ON FORMER NAO_ROBOT PACKAGE

naoqi_bridge
============

ROS stack to interact with Aldebaran's NAOqi, see http://wiki.ros.org/nao
