naoqi_tools
===========

This is a set of scripts allowing you to generate and modify Aldebaran's robot models easily, either description models (URDF) and visual models (Blender and mesh files)

Check the READMEs in the script directory for more detail
